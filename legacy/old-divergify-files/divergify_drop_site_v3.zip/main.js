
document.addEventListener('DOMContentLoaded', function () {
  const btn = document.querySelector('.signup button');
  if (btn) {
    btn.addEventListener('click', function () {
      const prev = btn.textContent;
      btn.textContent = 'Recalculating…';
      setTimeout(()=> btn.textContent = prev, 1600);
    });
  }

  // Rotating footer easter eggs
  const lines = [
    'We dispatch flying monkeys if you plagiarize. Legally speaking, please don’t test that.',
    'Tin Foil Hat Mode: now 27% shinier and 100% less tracky.',
    'Micro‑wins > macro‑worry.',
    'Hydrate. Then ship. In that order.',
    'If you can read this, your attention altitude is excellent.'
  ];
  const slot = document.querySelector('.footer-rotate');
  if (slot) {
    let i = 0;
    slot.textContent = lines[i%lines.length];
    setInterval(()=>{ i++; slot.textContent = lines[i%lines.length]; }, 7000);
  }

  // Konami code → secret toast
  const code = [38,38,40,40,37,39,37,39,66,65];
  let idx = 0;
  window.addEventListener('keydown', e => {
    if (e.keyCode === code[idx]) {
      idx++; if (idx === code.length) { idx = 0; easter(); }
    } else { idx = 0; }
  });
  function easter(){
    const d=document.createElement('div');
    d.textContent='Secret unlocked: Task Cake tastes better sliced.';
    d.style.position='fixed'; d.style.bottom='20px'; d.style.left='50%';
    d.style.transform='translateX(-50%)'; d.style.background='#102a1e';
    d.style.border='1px solid #1f5136'; d.style.color='#d6f4e6';
    d.style.padding='12px 16px'; d.style.borderRadius='12px'; d.style.zIndex='9999';
    document.body.appendChild(d);
    setTimeout(()=>d.remove(),4000);
  }
});
