---
title: Welcome to Divergify
date: 2025-11-05
---
This is the first post. We build for brains that refuse factory settings.
