import products from "@/lib/products.json"; import { notFound } from "next/navigation";
export default function Product({params}:{params:{slug:string}}){ const p=products.find(x=>x.slug===params.slug); if(!p) return notFound();
return (<div className="grid gap-2"><h1>{p.title}</h1><p style={{color:"#999"}}>{p.description}</p><p style={{fontWeight:800}}>${(p.priceCents/100).toFixed(2)}</p>
<form action="/api/checkout" method="POST"><input type="hidden" name="slug" value={p.slug}/><button className="btn btn-primary" type="submit">Buy</button></form></div>); }
