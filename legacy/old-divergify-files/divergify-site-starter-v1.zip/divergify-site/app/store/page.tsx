import products from "@/lib/products.json"; import Link from "next/link";
export default function Store(){ return (<div><h1>Store</h1><div style={{display:'grid',gap:12}}>{products.map(p=>(<div key={p.slug} className="card"><h3>{p.title}</h3><p style={{color:"#999"}}>{p.description}</p><Link className="btn" href={`/store/${p.slug}`}>View</Link></div>))}</div></div>); }
