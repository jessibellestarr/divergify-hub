import "./globals.css"; import Link from "next/link";
export const metadata = { title: "Divergify", description: "Community-powered neurodivergent productivity." };
export default function RootLayout({children}:{children:React.ReactNode}){
  return (<html lang="en"><body>
    <header style={{borderBottom:"1px solid #222"}}><nav className="container" style={{display:"flex",justifyContent:"space-between",padding:"1rem 0"}}>
      <Link href="/" className="no-underline" style={{fontWeight:900,fontSize:20}}>Divergify</Link>
      <div style={{display:"flex",gap:12}}>
        <Link href="/blog">Blog</Link><Link href="/community">Community</Link><Link href="/differentipedia">Differentipedia</Link>
        <Link href="/store">Store</Link><Link href="/merch-builder">Merch</Link><Link href="/download">Download</Link><Link href="/support">Tip</Link><Link className="btn btn-primary no-underline" href="/newsletter">What’s Next</Link>
      </div></nav></header>
    <main className="container" style={{padding:"1.5rem 0"}}>{children}</main>
    <footer style={{borderTop:"1px solid #222"}}><div className="container" style={{padding:"1rem 0",color:"#888",fontSize:12}}>© {new Date().getFullYear()} Divergify.</div></footer>
  </body></html>);
}
