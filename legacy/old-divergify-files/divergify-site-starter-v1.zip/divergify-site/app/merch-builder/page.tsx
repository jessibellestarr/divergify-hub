"use client"; import {useEffect,useRef,useState} from "react";
const PRESETS=["Did you just switch tasks?","Neurospicy and on purpose","Low-stim mode, high-impact","Tin Foil Hat Mode: ON","Ship then polish"];
export default function Merch(){ const c=useRef<HTMLCanvasElement>(null); const [text,setText]=useState(PRESETS[0]); const [bg,setBg]=useState("#000"); const [fg,setFg]=useState("#22c55e");
useEffect(()=>{const canvas=c.current!,ctx=canvas.getContext('2d')!; const W=canvas.width,H=canvas.height; ctx.fillStyle=bg; ctx.fillRect(0,0,W,H); ctx.fillStyle=fg; ctx.font="bold 64px system-ui"; ctx.textAlign="center"; ctx.textBaseline="middle";
const words=text.split(' '); const lines=[] as string[]; let cur=""; words.forEach(w=>{ if((cur+' '+w).trim().length>18){ lines.push(cur.trim()); cur=w; } else cur=(cur+' '+w).trim(); }); lines.push(cur.trim()); const y=H/2-(lines.length-1)*40; lines.forEach((l,i)=>ctx.fillText(l,W/2,y+i*80)); },[text,bg,fg]);
const dl=()=>{const url=c.current!.toDataURL('image/png'); const a=document.createElement('a'); a.href=url; a.download='divergify-design.png'; a.click();};
return (<div className="grid gap-4"><h1>Merch Builder</h1><div className="card"><div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
<select onChange={e=>setText(e.target.value)} className="btn">{PRESETS.map(p=><option key={p}>{p}</option>)}</select>
<input className="btn" value={text} onChange={e=>setText(e.target.value)}/>
<label>FG <input type="color" value={fg} onChange={e=>setFg(e.target.value)}/></label>
<label>BG <input type="color" value={bg} onChange={e=>setBg(e.target.value)}/></label>
<button className="btn btn-primary" onClick={dl}>Export PNG</button></div>
<canvas ref={c} width={1000} height={1000} style={{width:'100%',border:'1px solid #222',borderRadius:12,marginTop:12}}/></div></div>); }
