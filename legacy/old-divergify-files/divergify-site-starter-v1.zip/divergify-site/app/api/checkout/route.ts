import { NextRequest, NextResponse } from "next/server"; import Stripe from "stripe"; import products from "@/lib/products.json";
export async function POST(req:NextRequest){ const form=await req.formData(); const slug=String(form.get('slug')||''); const p=products.find(x=>x.slug===slug); if(!p) return NextResponse.json({}, {status:404});
const key=process.env.STRIPE_SECRET_KEY||''; if(!key) return NextResponse.json({url:'#'}); const stripe=new Stripe(key, {apiVersion:'2024-06-20'});
const session=await stripe.checkout.sessions.create({mode:'payment', line_items:[{price_data:{currency:'usd',product_data:{name:p.title},unit_amount:p.priceCents},quantity:1}], success_url:(process.env.AUTH_URL||'http://localhost:3000')+'/store', cancel_url:(process.env.AUTH_URL||'http://localhost:3000')+'/store'});
return NextResponse.redirect(session.url||'/store',{status:303}); }
