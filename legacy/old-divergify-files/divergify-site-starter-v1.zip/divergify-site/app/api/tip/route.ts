import { NextRequest, NextResponse } from "next/server"; import Stripe from "stripe";
export async function POST(req:NextRequest){ const form=await req.formData(); const a=String(form.get('amount')||'small');
const price = a==='large'?process.env.STRIPE_PRICE_TIP_LARGE: a==='medium'?process.env.STRIPE_PRICE_TIP_MEDIUM: process.env.STRIPE_PRICE_TIP_SMALL;
const key=process.env.STRIPE_SECRET_KEY||''; if(!key||!price) return NextResponse.json({url:'#'});
const stripe=new Stripe(key, {apiVersion:'2024-06-20'}); const session=await stripe.checkout.sessions.create({mode:'payment', line_items:[{price,quantity:1}], success_url:(process.env.AUTH_URL||'http://localhost:3000')+'/support', cancel_url:(process.env.AUTH_URL||'http://localhost:3000')+'/support'});
return NextResponse.redirect(session.url||'/support',{status:303}); }
