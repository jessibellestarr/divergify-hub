import { NextRequest, NextResponse } from "next/server"; import { appendFile } from "node:fs/promises"; import path from "node:path";
export async function POST(req:NextRequest){ const {email}=await req.json(); if(!email) return NextResponse.json({}, {status:400});
const file=path.join(process.cwd(),"data","emails.csv"); await appendFile(file, `${email},${new Date().toISOString()}\n`); return NextResponse.json({ok:true}); }
