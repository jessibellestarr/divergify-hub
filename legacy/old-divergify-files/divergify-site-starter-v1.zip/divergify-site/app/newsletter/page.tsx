"use client"; import { useState } from "react";
export default function News(){ const [email,setEmail]=useState(""); const [msg,setMsg]=useState("");
const submit=async()=>{ const r=await fetch('/api/newsletter',{method:'POST',body:JSON.stringify({email})}); setMsg(r.ok?'You’re on the list.':'Nope. Try again.'); setEmail(''); };
return (<div className="card"><h1>What’s Next</h1><p>V2 notes, drops, community calls.</p><div style={{display:'flex',gap:8}}><input value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@proton.me" className="btn" /><button className="btn btn-primary" onClick={submit}>Sign up</button></div><p>{msg}</p></div>); }
