import fs from "node:fs"; import path from "node:path"; import matter from "gray-matter"; import Link from "next/link";
export default function Blog(){
  const dir=path.join(process.cwd(),"content/blog"); const files=fs.existsSync(dir)?fs.readdirSync(dir):[];
  const posts = files.filter(f=>f.endsWith(".md")).map(f=>{const raw=fs.readFileSync(path.join(dir,f),"utf8"); const {data}=matter(raw); return {slug:f.replace(/\.md$/,''),...data}});
  return <div className="grid">{posts.map(p=>(<div key={p.slug} className="card"><h3><Link href={`/blog/${p.slug}`}>{p.title}</Link></h3><p style={{color:"#999"}}>{new Date(p.date).toDateString()}</p></div>))}</div>;
}
