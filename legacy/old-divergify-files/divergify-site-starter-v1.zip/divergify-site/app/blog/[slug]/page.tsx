import fs from "node:fs"; import path from "node:path"; import matter from "gray-matter"; import { notFound } from "next/navigation";
export default function Post({params}:{params:{slug:string}}){
  const f=path.join(process.cwd(),"content/blog",`${params.slug}.md`); if(!fs.existsSync(f)) return notFound();
  const {data,content}=matter(fs.readFileSync(f,'utf8')); return (<article><h1>{data.title}</h1><p style={{color:"#999"}}>{new Date(data.date).toDateString()}</p><pre style={{whiteSpace:"pre-wrap"}}>{content}</pre></article>);
}
