# Divergify Site (Stripe Test Key Preloaded)

## Run
npm i
npm run dev

## Payments (TEST MODE)
Uses your Stripe **test** secret key. Use test card 4242 4242 4242 4242 with any future expiry, any CVC/ZIP.
