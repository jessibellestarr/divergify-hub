
document.addEventListener('DOMContentLoaded', function () {
  const btn = document.querySelector('.signup button');
  if (btn) {
    btn.addEventListener('click', function () {
      const prev = btn.textContent;
      btn.textContent = 'Recalculating…';
      setTimeout(()=> btn.textContent = prev, 1600);
    });
  }

  // Rotating footer easter eggs
  const lines = [
    'We dispatch flying monkeys if you plagiarize. Legally speaking, please don’t test that.',
    'Tin Foil Hat Mode: now 27% shinier and 100% less tracky.',
    'Micro‑wins > macro‑worry.',
    'Hydrate. Then ship. In that order.',
    'If you can read this, your attention altitude is excellent.'
  ];
  const slot = document.querySelector('.footer-rotate');
  if (slot) {
    let i = 0;
    slot.textContent = lines[i%lines.length];
    setInterval(()=>{ i++; slot.textContent = lines[i%lines.length]; }, 7000);
  }

  // Konami code → secret toast
  const code = [38,38,40,40,37,39,37,39,66,65];
  let idx = 0;
  window.addEventListener('keydown', e => {
    if (e.keyCode === code[idx]) {
      idx++; if (idx === code.length) { idx = 0; easter(); }
    } else { idx = 0; }
  });
  function easter(){
    const d=document.createElement('div');
    d.textContent='Secret unlocked: Task Cake tastes better sliced.';
    d.style.position='fixed'; d.style.bottom='20px'; d.style.left='50%';
    d.style.transform='translateX(-50%)'; d.style.background='#102a1e';
    d.style.border='1px solid #1f5136'; d.style.color='#d6f4e6';
    d.style.padding='12px 16px'; d.style.borderRadius='12px'; d.style.zIndex='9999';
    document.body.appendChild(d);
    setTimeout(()=>d.remove(),4000);
  }
});


// Build merch carousel from JSON
async function loadMerch(){
  try{
    const res = await fetch('/assets/merch.json',{cache:'no-cache'});
    const items = await res.json();
    const mount = document.getElementById('merch-mount');
    if(!mount) return;
    const wrap = document.createElement('div'); wrap.className='carousel';
    const track = document.createElement('div'); track.className='carousel-track';
    wrap.appendChild(track);

    items.forEach(it=>{
      const slide = document.createElement('div'); slide.className='carousel-item';
      slide.innerHTML = \`
        <img src="\${it.image}" alt="\${it.title}">
        <div class="carousel-meta">
          <h3>\${it.title}</h3>
          <div class="price">\${it.price}</div>
          <a class="cta" href="\${it.url}" target="_blank" rel="noopener">View on Printful</a>
        </div>\`;
      track.appendChild(slide);
    });

    const prev = document.createElement('button'); prev.className='nav prev'; prev.textContent='‹';
    const next = document.createElement('button'); next.className='nav next'; next.textContent='›';
    wrap.appendChild(prev); wrap.appendChild(next);

    const dots = document.createElement('div'); dots.className='carousel-dots';
    wrap.appendChild(dots);

    let idx=0;
    function go(i){
      idx = (i+items.length)%items.length;
      track.style.transform = \`translateX(-\${idx*100}%)\`;
      Array.from(dots.children).forEach((d,k)=> d.classList.toggle('active', k===idx));
    }
    items.forEach((_,i)=>{
      const d=document.createElement('button');
      d.addEventListener('click',()=>go(i));
      dots.appendChild(d);
    });
    dots.firstChild && dots.firstChild.classList.add('active');

    prev.addEventListener('click',()=>go(idx-1));
    next.addEventListener('click',()=>go(idx+1));

    mount.appendChild(wrap);
    let timer = setInterval(()=>go(idx+1), 6000);
    wrap.addEventListener('mouseenter',()=>clearInterval(timer));
    wrap.addEventListener('mouseleave',()=>timer=setInterval(()=>go(idx+1), 6000));

    go(0);
  }catch(e){ console.warn('merch failed', e); }
}
loadMerch();
