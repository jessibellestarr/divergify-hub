

## Merch carousel
- Edit `/assets/merch.json` to control the items.
- Each item needs: `title`, `price`, `url` (your Printful/Printify/Shop url), `image` (path or absolute URL).
- Replace the PNGs in `/assets/` with real product photos when ready.
