let enabled = false;
export const tinFoilEnabled = () => enabled;
export const setTinFoil = (value: boolean) => { enabled = value; };

// Example network guard shim: wrap fetch to block calls when tinfoil is on.
export const guardedFetch: typeof fetch = async (input: RequestInfo | URL, init?: RequestInit) => {
  if (enabled) throw new Error("Tin Foil Hat mode is ON: outbound network blocked.");
  return fetch(input, init);
};
