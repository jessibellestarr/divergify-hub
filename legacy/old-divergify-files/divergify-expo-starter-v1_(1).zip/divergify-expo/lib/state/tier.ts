import AsyncStorage from "@react-native-async-storage/async-storage";
export type Tier = "free" | "premium";

let current: Tier = "free";

export const saveTier = (t: Tier) => { current = t; AsyncStorage.setItem("tier", t).catch(() => {}); };
export const getTier = () => current;
export const isMirrorMode = () => current === "premium";
