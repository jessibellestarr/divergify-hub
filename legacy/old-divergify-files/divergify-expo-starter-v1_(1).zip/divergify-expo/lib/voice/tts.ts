import * as Speech from "expo-speech";

export const speak = (text: string) => {
  try { Speech.speak(text, { language: "en-US", pitch: 1.0, rate: 0.9 }); }
  catch {}
};
