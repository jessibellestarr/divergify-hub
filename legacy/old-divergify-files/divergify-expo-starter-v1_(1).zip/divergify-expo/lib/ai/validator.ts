type Checks = {
  brandTone: boolean;
  monetizationAligned: boolean;
  psychologyBacked: boolean;
  empowerment: boolean;
  securityCompliant: boolean;
};

export const validator = (checks: Checks): { ok: boolean; reason?: string } => {
  const failures: string[] = [];
  if (!checks.brandTone) failures.push("Brand tone misaligned");
  if (!checks.monetizationAligned) failures.push("Monetization not serving mission");
  if (!checks.psychologyBacked) failures.push("No grounding in behavioral science");
  if (!checks.empowerment) failures.push("User control missing");
  if (!checks.securityCompliant) failures.push("Security/privacy noncompliant");
  return failures.length ? { ok: false, reason: failures.join("; ") } : { ok: true };
};
