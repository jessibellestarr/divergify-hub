import { useLocalSearchParams } from "expo-router";
import { View, Text, Pressable, StyleSheet } from "react-native";
import personas from "@/lib/config/personas.json";
import { speak } from "@/lib/voice/tts";
import { useState } from "react";
import { validator } from "@/lib/ai/validator";
import systemPrompt from "@/lib/ai/system-prompt.md?raw";
import { getTier } from "@/lib/state/tier";

export default function Sidekick() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const p = personas.find(x => x.id === id) ?? personas[0];
  const [lastCheck, setLastCheck] = useState<string>("");

  const handleValidate = () => {
    const res = validator({
      brandTone: true,
      monetizationAligned: true,
      psychologyBacked: true,
      empowerment: true,
      securityCompliant: true,
    });
    setLastCheck(res.ok ? "✅ Passed self-check" : "❌ Failed: " + res.reason);
  };

  const say = () => speak(p.greeting.en);

  return (
    <View style={styles.container}>
      <Text style={[styles.h1, { color: p.color }]}>{p.name}</Text>
      <Text style={styles.body}>{p.greeting.en}</Text>
      <Pressable style={styles.btn} onPress={say}><Text style={styles.btnText}>Speak greeting</Text></Pressable>
      <Pressable style={styles.btn} onPress={handleValidate}><Text style={styles.btnText}>Run self-check</Text></Pressable>
      {lastCheck ? <Text style={styles.note}>{lastCheck}</Text> : null}
      <Text style={styles.small}>Tier: {getTier()}</Text>
      <Text style={styles.small}>System prompt length: {systemPrompt.length} chars</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#000", padding: 16 },
  h1: { fontSize: 28, fontWeight: "900" },
  body: { color: "#cbd5e1", marginVertical: 8 },
  btn: { backgroundColor: "#111827", borderColor: "#27272a", borderWidth: 1, padding: 10, borderRadius: 10, marginRight: 8, marginVertical: 6 },
  btnText: { color: "#e5e7eb", fontWeight: "600" },
  note: { color: "#a7f3d0", marginTop: 6 },
  small: { color: "#9ca3af", marginTop: 6, fontSize: 12 }
});
