import { View, Text, Pressable, StyleSheet } from "react-native";
import { useRouter } from "expo-router";
import * as SecureStore from "expo-secure-store";

export default function Onboarding() {
  const router = useRouter();
  return (
    <View style={styles.container}>
      <Text style={styles.h1}>Welcome to Divergify</Text>
      <Text style={styles.body}>Pick stimulation level, privacy, and a sidekick. You control everything. Nothing is forced.</Text>
      <Pressable style={styles.btn} onPress={() => router.replace("/")}>
        <Text style={styles.btnText}>Finish</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#000", padding: 16, justifyContent: "center" },
  h1: { color: "white", fontSize: 28, fontWeight: "900", marginBottom: 12 },
  body: { color: "#cbd5e1", marginBottom: 20 },
  btn: { backgroundColor: "#22c55e", padding: 12, borderRadius: 12, alignSelf: "flex-start" },
  btnText: { fontWeight: "800" }
});
