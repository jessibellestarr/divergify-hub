import { Link } from "expo-router";
import { View, Text, Pressable, ScrollView, StyleSheet } from "react-native";
import { StatusBar } from "expo-status-bar";
import personas from "@/lib/config/personas.json";
import { useState } from "react";
import { saveTier, Tier, getTier } from "@/lib/state/tier";
import { tinFoilEnabled, setTinFoil } from "@/lib/privacy/tinfoil";

export default function Home() {
  const [tier, setTier] = useState<Tier>("free");
  const [tinfoil, setTF] = useState<boolean>(false);

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.center}>
      <Text style={styles.h1}>Divergify</Text>
      <Text style={styles.subtitle}>Voice-first productivity for spicy brains.</Text>

      <View style={styles.row}>
        <Pressable style={[styles.btn, tier === "free" && styles.btnActive]} onPress={() => { saveTier("free"); setTier("free"); }}>
          <Text style={styles.btnText}>Free</Text>
        </Pressable>
        <Pressable style={[styles.btn, tier === "premium" && styles.btnActive]} onPress={() => { saveTier("premium"); setTier("premium"); }}>
          <Text style={styles.btnText}>Premium</Text>
        </Pressable>
      </View>

      <View style={styles.row}>
        <Pressable style={[styles.btn, tinfoil && styles.btnActive]} onPress={() => { const v = !tinfoil; setTF(v); setTinFoil(v); }}>
          <Text style={styles.btnText}>{tinfoil ? "Tin Foil Hat: ON" : "Tin Foil Hat: OFF"}</Text>
        </Pressable>
      </View>

      <View style={{ height: 16 }} />

      <Link href="/onboarding" asChild>
        <Pressable style={[styles.btn, styles.btnPrimary]}>
          <Text style={[styles.btnText, styles.btnPrimaryText]}>Start onboarding</Text>
        </Pressable>
      </Link>

      <View style={{ height: 24 }} />

      <Text style={styles.h2}>Sidekicks</Text>
      {personas.map(p => (
        <View key={p.id} style={[styles.card, { borderColor: p.color }]}>
          <Text style={styles.cardTitle}>{p.name}</Text>
          <Text style={styles.cardSub}>{p.role}</Text>
          <Text style={styles.cardBody}>{p.greeting.en}</Text>
          <Link href={`/sidekick/${p.id}`} asChild>
            <Pressable style={styles.btn}>
              <Text style={styles.btnText}>Open</Text>
            </Pressable>
          </Link>
        </View>
      ))}

      <StatusBar style="light" />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { backgroundColor: "#0a0a0a" },
  center: { padding: 16, paddingBottom: 64 },
  h1: { color: "white", fontSize: 32, fontWeight: "800", marginBottom: 6 },
  subtitle: { color: "#a1a1aa", marginBottom: 16 },
  h2: { color: "white", fontSize: 20, fontWeight: "700", marginVertical: 12 },
  row: { flexDirection: "row", gap: 8 },
  btn: { backgroundColor: "#111827", borderColor: "#27272a", borderWidth: 1, paddingVertical: 10, paddingHorizontal: 14, borderRadius: 10 },
  btnActive: { borderColor: "#38bdf8" },
  btnPrimary: { backgroundColor: "#22c55e", borderColor: "#16a34a" },
  btnPrimaryText: { color: "#000" },
  btnText: { color: "#e5e7eb", fontWeight: "600" },
  card: { borderWidth: 2, borderRadius: 14, padding: 12, marginBottom: 10, backgroundColor: "#0b1220" },
  cardTitle: { color: "white", fontWeight: "800", fontSize: 18 },
  cardSub: { color: "#93c5fd", marginBottom: 8 },
  cardBody: { color: "#cbd5e1", marginBottom: 10 }
});
