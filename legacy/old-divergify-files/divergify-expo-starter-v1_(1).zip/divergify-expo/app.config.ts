import { ExpoConfig } from 'expo/config';

export default ({ config }: { config: ExpoConfig }) => ({
  ...config,
  name: "Divergify",
  slug: "divergify-expo",
  scheme: "divergify",
  version: "0.1.0",
  orientation: "portrait",
  icon: "./assets/icon.png",
  userInterfaceStyle: "automatic",
  splash: {
    image: "./assets/splash.png",
    resizeMode: "contain",
    backgroundColor: "#000000"
  },
  updates: { enabled: true },
  assetBundlePatterns: ["**/*"],
  ios: { supportsTablet: true },
  android: { adaptiveIcon: { foregroundImage: "./assets/adaptive-icon.png", backgroundColor: "#000000" } },
  web: { bundler: "metro", output: "static", favicon: "./assets/favicon.png" },
  experiments: { typedRoutes: true },
});
