# Divergify Expo Starter

A minimal Expo Router + TypeScript scaffold with:
- Personas config
- System prompt file
- Free vs Premium tier toggle
- Tin Foil Hat privacy shim (blocks network when enabled)
- Self-validation helper
- Basic TTS example

## Quick start
1) Install Node 18+ and `npm i -g expo-cli` (or use `npx`).
2) Install deps: `npm install`
3) Run: `npm start` (or `npx expo start`)
4) Open on device with Expo Go or on a simulator.

## Files of interest
- `lib/config/personas.json` — the five sidekicks
- `lib/ai/system-prompt.md` — Takoda system prompt
- `lib/ai/validator.ts` — self-check logic
- `lib/state/tier.ts` — Free vs Premium, Mirror Mode gate
- `lib/privacy/tinfoil.ts` — outbound network blocker
- `app/sidekick/[id].tsx` — sample screen demonstrating usage

## Security & privacy
- No analytics by default.
- Tin Foil Hat mode blocks outbound `fetch` via `guardedFetch` helper.
- Store secrets in Expo's secure config or use native secure storage for tokens.

## License
For internal Divergify use.
