// To be implemented in Sprint E
export function initSupabase(){}