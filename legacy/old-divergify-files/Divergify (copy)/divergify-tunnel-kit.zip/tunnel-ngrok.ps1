# Requires ngrok installed and authtoken configured
Write-Host 'Starting ngrok tunnel to http://localhost:8787 ...'
ngrok http 8787
