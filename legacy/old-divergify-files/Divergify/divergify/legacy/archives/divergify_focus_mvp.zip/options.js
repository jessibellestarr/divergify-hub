
const STORAGE = { settings:'settings' };
const DEFAULTS = {
  focusMinutes: 25,
  breakMinutes: 5,
  blocklist: ['twitter.com', 'facebook.com', 'instagram.com', 'tiktok.com', 'reddit.com', 'youtube.com'],
};

async function load() {
  const data = await chrome.storage.local.get([STORAGE.settings]);
  const s = data[STORAGE.settings] || DEFAULTS;
  document.getElementById('focus').value = s.focusMinutes || 25;
  document.getElementById('break').value = s.breakMinutes || 5;
  document.getElementById('blocklist').value = (s.blocklist || DEFAULTS.blocklist).join('\\n');
}
load();

document.getElementById('save').onclick = async () => {
  const s = {
    focusMinutes: parseInt(document.getElementById('focus').value, 10) || 25,
    breakMinutes: parseInt(document.getElementById('break').value, 10) || 5,
    blocklist: document.getElementById('blocklist').value.split('\\n').map(x=>x.trim()).filter(Boolean),
  };
  await chrome.storage.local.set({settings: s});
  document.getElementById('status').textContent = 'Saved.';
  setTimeout(()=>document.getElementById('status').textContent='', 1500);
};

document.getElementById('reset').onclick = async () => {
  await chrome.storage.local.set({settings: DEFAULTS});
  load();
};
