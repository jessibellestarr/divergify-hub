
# Divergify Focus (MVP) — Chrome/Edge/Brave Extension

Features:
- Pomodoro (25/5 default) with notifications
- Focus Lock: blocks listed sites during focus sessions
- Personas: Takoda, Coach, Soothe, Strategist (Avery), Gremlin (Mox)
- Rewards: sarcastic/big messages with 72h no-repeat
- Auto-update: optional URL to fetch updated settings JSON

## Install (Chrome/Edge/Brave)
1) Go to chrome://extensions (or edge://extensions, brave://extensions)
2) Enable "Developer mode"
3) Click "Load unpacked" and select this folder
4) Pin the extension; open popup to start

## Options
- Right-click the icon → "Options" to set blocklist and durations
- In popup, you can set an optional Auto-update URL, e.g., https://YOUR-SITE/update.json

## Auto-update JSON format
{
  "focusMinutes": 30,
  "breakMinutes": 5,
  "blocklist": ["twitter.com","youtube.com"]
}

## Notes
- This MVP uses Manifest V3 with dynamic DNR rules for blocking.
- Firefox supports MV3 but behaviors differ; a separate package may be needed.
