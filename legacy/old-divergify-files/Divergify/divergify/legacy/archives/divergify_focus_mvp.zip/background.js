
// background.js (MV3, module)
const STORAGE = {
  settings: 'settings',
  state: 'state',
  recentMessages: 'recentMessages'
};

const DEFAULTS = {
  focusMinutes: 25,
  breakMinutes: 5,
  blocklist: ['twitter.com', 'facebook.com', 'instagram.com', 'tiktok.com', 'reddit.com', 'youtube.com'],
  persona: 'Takoda',
  updateUrl: '' // e.g., 'https://YOUR-NETLIFY-SITE/update.json'
};

const PERSONAS = {
  Takoda: {name:'Takoda', tone:'funny-blunt', messages:[
    "First win logged. Small glitter poof. Keep going.",
    "Progress > perfection. Next tiny step, now.",
    "Look at you, chaos tamer. One box checked.",
    "Momentum’s hot. Don’t let it cool."
  ]},
  Coach: {name:'Coach', tone:'motivational', messages:[
    "Nice rep. Water break, then back in.",
    "One brick at a time. Lay another.",
    "You showed up. That’s the hardest part.",
    "Consistency beats intensity. Keep it steady."
  ]},
  Soothe: {name:'Soothe', tone:'calm', messages:[
    "Gentle win. Breathe in, breathe out.",
    "Micro-move made. Your pace is enough.",
    "You did a thing. Let that feel okay.",
    "Next tiny step when you’re ready."
  ]},
  Strategist: {name:'Avery', tone:'serious', messages:[
    "Checkpoint reached. Update your plan.",
    "Good. Reduce scope; increase throughput.",
    "Queue the next high-impact task.",
    "Systems over willpower. Optimize now."
  ]},
  Gremlin: {name:'Mox', tone:'chaotic', messages:[
    "HEH. BUTTON SMASHED. MORE!",
    "GLITTER CANNON ARMING — JUST KIDDING (OR AM I).",
    "You finished? We feast on dopamine now.",
    "Gremlin approves. Continue the rampage."
  ]}
};

const MSG_POOL = {
  sarcastic: [
    "Congrats on doing the bare minimum — which is still progress. 😉",
    "Tiny win, huge ego. I like it.",
    "Impressive. Didn’t even open 12 tabs first.",
    "Against all odds (and notifications), you did it."
  ],
  big: [
    "KA-BOOM. Graffiti bomb of glory.",
    "Confetti storm unlocked. Legend.",
    "Dopamine jackpot. Cash it in: next step."
  ]
};

// Helpers
const get = (keys) => new Promise(res => chrome.storage.local.get(keys, res));
const set = (obj) => new Promise(res => chrome.storage.local.set(obj, res));
const now = () => Date.now();

async function ensureDefaults() {
  const data = await get([STORAGE.settings, STORAGE.state, STORAGE.recentMessages]);
  if (!data[STORAGE.settings]) await set({[STORAGE.settings]: DEFAULTS});
  if (!data[STORAGE.state]) await set({[STORAGE.state]: {focusActive:false, until:0}});
  if (!data[STORAGE.recentMessages]) await set({[STORAGE.recentMessages]: []});
}
ensureDefaults();

// Declarative Net Request: dynamic rules for blocklist
async function applyBlockRules(enabled) {
  const { settings } = await get([STORAGE.settings]);
  const blocklist = (settings?.blocklist || DEFAULTS.blocklist).filter(Boolean);
  const ruleIds = blocklist.map((_, i) => 1000 + i);

  if (!enabled) {
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: ruleIds });
    return;
  }

  const rules = blocklist.map((host, i) => ({
    id: 1000 + i,
    priority: 1,
    action: { type: "block" },
    condition: { urlFilter: host, resourceTypes: ["main_frame"] }
  }));

  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: ruleIds,
    addRules: rules
  });
}

// Pomodoro via alarms
async function startFocusTimer() {
  const { settings } = await get([STORAGE.settings]);
  const minutes = settings?.focusMinutes || DEFAULTS.focusMinutes;
  await chrome.alarms.clearAll();
  await chrome.alarms.create("focus-end", { delayInMinutes: minutes });
  await set({[STORAGE.state]: {focusActive:true, until: now() + minutes*60*1000}});
  await applyBlockRules(true);
  notify("Focus started", `You’re locked in for ${minutes} minutes.`);
}

async function startBreakTimer() {
  const { settings } = await get([STORAGE.settings]);
  const minutes = settings?.breakMinutes || DEFAULTS.breakMinutes;
  await chrome.alarms.clearAll();
  await chrome.alarms.create("break-end", { delayInMinutes: minutes });
  await set({[STORAGE.state]: {focusActive:false, until: now() + minutes*60*1000}});
  await applyBlockRules(false);
  notify("Break started", `Rest ${minutes} minutes. Stretch, water, breathe.`);
}

async function stopAllTimers() {
  await chrome.alarms.clearAll();
  await set({[STORAGE.state]: {focusActive:false, until:0}});
  await applyBlockRules(false);
  notify("Focus off", "Focus Lock disabled.");
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === "focus-end") {
    reward('sarcastic'); // small win
    await startBreakTimer();
  } else if (alarm.name === "break-end") {
    reward('big'); // hype
    await startFocusTimer();
  } else if (alarm.name === "auto-update") {
    fetchUpdates();
  }
});

// Notifications
function notify(title, message) {
  chrome.notifications.create({
    type: "basic",
    iconUrl: "icons/icon128.png",
    title, message
  });
}

// Rewards with 72h non-repeat rule
async function reward(bucket='sarcastic') {
  const { recentMessages } = await get([STORAGE.recentMessages]);
  const WINDOW = 72 * 60 * 60 * 1000;
  const cutoff = now() - WINDOW;
  const used = (recentMessages || []).filter(m => m.when > cutoff);
  const usedTexts = new Set(used.map(m => m.text));

  const pool = MSG_POOL[bucket] || MSG_POOL.sarcastic;
  const choice = pool.find(t => !usedTexts.has(t)) || pool[0];

  used.push({ text: choice, when: now() });
  await set({[STORAGE.recentMessages]: used});
  notify("Win logged", choice);
}

// Messages from popup
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    if (msg.type === 'START_FOCUS') await startFocusTimer();
    if (msg.type === 'STOP_ALL') await stopAllTimers();
    if (msg.type === 'COMPLETE_TASK') await reward('sarcastic');
    if (msg.type === 'SET_PERSONA') {
      const data = await get([STORAGE.settings]);
      const s = data[STORAGE.settings] || DEFAULTS;
      s.persona = msg.persona || 'Takoda';
      await set({[STORAGE.settings]: s});
      notify("Persona set", `Voice: ${s.persona}`);
    }
    if (msg.type === 'APPLY_BLOCKLIST') {
      await applyBlockRules(msg.enabled);
    }
    sendResponse({ok:true});
  })();
  return true;
});

// Auto-update (messages, blocklist) every 6 hours
chrome.runtime.onInstalled.addListener(async () => {
  await ensureDefaults();
  await chrome.alarms.create("auto-update", { periodInMinutes: 360 });
});

async function fetchUpdates() {
  const { settings } = await get([STORAGE.settings]);
  const url = settings?.updateUrl;
  if (!url) return;
  try {
    const res = await fetch(url, { cache: 'no-cache' });
    if (!res.ok) return;
    const data = await res.json();
    const s = settings || DEFAULTS;
    if (Array.isArray(data.blocklist)) s.blocklist = data.blocklist;
    if (typeof data.focusMinutes === 'number') s.focusMinutes = data.focusMinutes;
    if (typeof data.breakMinutes === 'number') s.breakMinutes = data.breakMinutes;
    await set({[STORAGE.settings]: s});
    notify("Auto-update", "Settings refreshed from server.");
  } catch(e) {
    // silent
  }
}
