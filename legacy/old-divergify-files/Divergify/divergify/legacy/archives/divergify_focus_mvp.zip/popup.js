
const $ = (id)=>document.getElementById(id);
const fmt = (ms)=>{
  const s = Math.max(0, Math.floor(ms/1000));
  const m = Math.floor(s/60).toString().padStart(2,'0');
  const r = (s%60).toString().padStart(2,'0');
  return `${m}:${r}`;
};

const STORAGE = { settings:'settings', state:'state' };

async function load() {
  const data = await chrome.storage.local.get([STORAGE.settings, STORAGE.state]);
  const s = data[STORAGE.settings] || {};
  const st = data[STORAGE.state] || {focusActive:false, until:0};
  $('persona').value = s.persona || 'Takoda';
  $('updateUrl').value = s.updateUrl || '';
  $('lock').checked = st.focusActive;
  updateUI(st);
}
load();

function updateUI(st){
  const active = st.focusActive;
  $('status').textContent = active ? 'Focusing' : 'Idle / Break';
  tick(st.until, active);
}

let timerId;
function tick(until, active){
  if (timerId) clearInterval(timerId);
  const paint = () => {
    const left = until - Date.now();
    $('timer').textContent = fmt(left);
    if (left <= 0) clearInterval(timerId);
  };
  paint();
  timerId = setInterval(paint, 1000);
}

$('start').onclick = async () => {
  await chrome.runtime.sendMessage({type:'START_FOCUS'});
  const { state } = await chrome.storage.local.get(['state']);
  updateUI(state);
  if ($('lock').checked) await chrome.runtime.sendMessage({type:'APPLY_BLOCKLIST', enabled:true});
};

$('stop').onclick = async () => {
  await chrome.runtime.sendMessage({type:'STOP_ALL'});
  const { state } = await chrome.storage.local.get(['state']);
  updateUI(state);
  $('lock').checked = false;
};

$('task').onclick = async () => {
  await chrome.runtime.sendMessage({type:'COMPLETE_TASK'});
};

$('persona').onchange = async (e) => {
  await chrome.runtime.sendMessage({type:'SET_PERSONA', persona: e.target.value});
};

$('save').onclick = async () => {
  const data = await chrome.storage.local.get(['settings']);
  const s = data.settings || {};
  s.updateUrl = $('updateUrl').value.trim();
  await chrome.storage.local.set({settings: s});
  alert('Saved.');
};
