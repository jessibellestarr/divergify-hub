Place your final glossary PDF here as: divergify-glossary.pdf
Tip: Open ../glossary.html in your browser and "Print to PDF" (or export) to create the file.
