import { Audio } from 'expo-av';
import { Platform } from 'react-native';

export async function speak(text, personaId = 'henry') {
  const api = process.env.EXPO_PUBLIC_API_URL;
  if (!api) throw new Error('Missing EXPO_PUBLIC_API_URL');

  const resp = await fetch(`${api}/tts`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text, personaId })
  });

  if (!resp.ok) {
    const err = await resp.json().catch(() => ({}));
    throw new Error(err?.error || 'TTS failed');
  }

  const arrayBuf = await resp.arrayBuffer();
  const base64 = Platform.OS === 'web'
    ? btoa(String.fromCharCode(...new Uint8Array(arrayBuf)))
    : Buffer.from(arrayBuf).toString('base64');

  const { sound } = await Audio.Sound.createAsync({
    uri: `data:audio/mpeg;base64,${base64}`
  });
  await sound.playAsync();
  return sound;
}
