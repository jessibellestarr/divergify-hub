import { Audio } from 'expo-av';

export async function recordAndTranscribe(ms = 6000) {
  const api = process.env.EXPO_PUBLIC_API_URL;
  if (!api) throw new Error('Missing EXPO_PUBLIC_API_URL');

  const perm = await Audio.requestPermissionsAsync();
  if (!perm.granted) throw new Error('Microphone permission denied');

  const rec = new Audio.Recording();
  await rec.prepareToRecordAsync(Audio.RecordingOptionsPresets.HIGH_QUALITY);
  await rec.startAsync();
  await new Promise(r => setTimeout(r, ms));
  await rec.stopAndUnloadAsync();

  const uri = rec.getURI();
  if (!uri) throw new Error('No recording');
  const name = 'audio.m4a';

  const form = new FormData();
  form.append('audio', { uri, name, type: 'audio/m4a' });

  const resp = await fetch(`${api}/stt`, { method: 'POST', body: form });
  if (!resp.ok) {
    const err = await resp.json().catch(() => ({}));
    throw new Error(err?.error || 'STT failed');
  }
  const data = await resp.json();
  return data.text;
}
