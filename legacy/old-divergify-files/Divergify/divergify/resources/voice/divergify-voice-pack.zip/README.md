# Divergify Voice Pack (TTS/STT Personas)

Drop-in starter to add **voice personas** (e.g., Henry, Gremlin, Coach, Soothe) to Divergify.
It includes:
- Node/Express backend with **/api/tts** and **/api/stt**
- Persona registry with configurable tone, phrases, and 72-hour no-repeat rewards
- React Native (Expo) hooks to **play TTS** and **record+transcribe** (STT)
- Tin Foil Hat Mode (disable remote TTS/STT)

## Quickstart

1) Copy `.env.example` to `.env` and set your `OPENAI_API_KEY`.
2) Install deps: `npm i`
3) Start server: `npm run dev` (or `npm start`)
4) From the app, set `EXPO_PUBLIC_API_URL=http://YOUR-IP:3001/api`
5) Use the hooks in `client/hooks/`:
   - `speak("Right then, let’s get you unstuck.", "henry")`
   - `const text = await recordAndTranscribe(5000)`

## Endpoints
- `POST /api/tts` JSON `{ text, personaId }` -> MP3 audio
- `POST /api/stt` form-data `audio` -> `{ text }`

## Tin Foil Hat Mode
Set `TIN_FOIL_HAT=true` in `.env` to block outbound API calls (use system TTS in client).

## Notes
- No native modules required on server. Phrase history saved to a JSON file.
- Personas live in `server/personas/` (Henry, Gremlin, Coach, Soothe).
- Edit catchphrases safely; the reward selector avoids repeats within 72 hours.
