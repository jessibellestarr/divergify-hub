import fs from 'fs';
import path from 'path';

const DB_PATH = path.join(process.cwd(), 'server', 'db', 'phrase_uses.json');

function loadDb() {
  try {
    const raw = fs.readFileSync(DB_PATH, 'utf-8');
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

function saveDb(rows) {
  fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
  fs.writeFileSync(DB_PATH, JSON.stringify(rows, null, 2), 'utf-8');
}

export function pickPhrase(personaId, phrases) {
  const rows = loadDb();
  const cutoff = Date.now() - 72 * 3600 * 1000;
  const recentSet = new Set(
    rows
      .filter(r => r.persona === personaId && r.used_at >= cutoff)
      .map(r => r.phrase)
  );

  const pool = phrases.filter(p => !recentSet.has(p));
  const src = pool.length ? pool : phrases;
  const choice = src[Math.floor(Math.random() * src.length)];

  rows.push({ persona: personaId, phrase: choice, used_at: Date.now() });
  saveDb(rows);
  return choice;
}
