import { HENRY } from './henry.js';
import { GREMLIN } from './gremlin.js';
import { COACH } from './coach.js';
import { SOOTHE } from './soothe.js';

export const PERSONAS = {
  [HENRY.id]: HENRY,
  [GREMLIN.id]: GREMLIN,
  [COACH.id]: COACH,
  [SOOTHE.id]: SOOTHE
};

export function getPersona(id) {
  return PERSONAS[id] || HENRY;
}
