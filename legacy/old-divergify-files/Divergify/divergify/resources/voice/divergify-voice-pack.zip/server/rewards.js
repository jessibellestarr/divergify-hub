import { getPersona } from './personas/index.js';
import { pickPhrase } from './db/phraseRotation.js';

export function rewardLine(personaId = 'henry') {
  const persona = getPersona(personaId);
  return pickPhrase(persona.id, persona.catchphrases || []);
}
