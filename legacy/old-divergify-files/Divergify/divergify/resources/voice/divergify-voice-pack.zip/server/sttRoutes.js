import express from 'express';
import multer from 'multer';
import fs from 'fs';
import OpenAI from 'openai';

const upload = multer({ dest: '/tmp' });
const router = express.Router();
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

router.post('/stt', upload.single('audio'), async (req, res) => {
  try {
    if (String(process.env.TIN_FOIL_HAT).toLowerCase() === 'true') {
      return res.status(403).json({ error: 'Tin Foil Hat Mode: remote STT is disabled.' });
    }
    if (!req.file) return res.status(400).json({ error: 'No audio file' });

    const filePath = req.file.path;
    const tryModels = ['gpt-4o-mini-transcribe', 'whisper-1'];
    let transcript = null;
    let lastErr = null;

    for (const model of tryModels) {
      try {
        transcript = await openai.audio.transcriptions.create({
          file: fs.createReadStream(filePath),
          model
        });
        break;
      } catch (e) {
        lastErr = e;
      }
    }
    fs.unlink(filePath, () => {});
    if (!transcript) throw lastErr || new Error('All STT models failed');

    const text = transcript.text || transcript?.data?.text || '';
    res.json({ text });
  } catch (err) {
    console.error('[STT] error', err);
    res.status(500).json({ error: 'STT failed' });
  }
});

export default router;
