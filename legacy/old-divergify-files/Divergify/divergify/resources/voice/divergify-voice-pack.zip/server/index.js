import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import path from 'path';
import voiceRoutes from './voiceRoutes.js';
import sttRoutes from './sttRoutes.js';

const app = express();

const origins = (process.env.ALLOW_ORIGINS || '*').split(',');
app.use(cors({ origin: origins, credentials: false }));
app.use(express.json({ limit: '2mb' }));

app.use('/api', voiceRoutes);
app.use('/api', sttRoutes);

const port = Number(process.env.PORT || 3001);
app.listen(port, () => {
  console.log(`[Divergify Voice] Server listening on http://localhost:${port}`);
});
