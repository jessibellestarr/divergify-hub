import express from 'express';
import OpenAI from 'openai';
import { getPersona } from './personas/index.js';

const router = express.Router();
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

router.post('/tts', async (req, res) => {
  try {
    if (String(process.env.TIN_FOIL_HAT).toLowerCase() === 'true') {
      return res.status(403).json({ error: 'Tin Foil Hat Mode: remote TTS is disabled.' });
    }

    const { text, personaId = 'henry' } = req.body || {};
    if (!text || typeof text !== 'string') {
      return res.status(400).json({ error: 'Missing text' });
    }
    const persona = getPersona(personaId);

    const tryModels = [persona.ttsModel, 'tts-1'];
    let audioResp = null;
    let lastErr = null;

    for (const model of tryModels) {
      try {
        audioResp = await openai.audio.speech.create({
          model,
          voice: persona.voiceId,
          input: text,
          format: 'mp3'
        });
        break;
      } catch (e) {
        lastErr = e;
      }
    }
    if (!audioResp) throw lastErr || new Error('All TTS models failed');

    const arrayBuf = await audioResp.arrayBuffer();
    const buf = Buffer.from(arrayBuf);
    res.set('Content-Type', 'audio/mpeg');
    res.send(buf);
  } catch (err) {
    console.error('[TTS] error', err);
    res.status(500).json({ error: 'TTS failed' });
  }
});

export default router;
