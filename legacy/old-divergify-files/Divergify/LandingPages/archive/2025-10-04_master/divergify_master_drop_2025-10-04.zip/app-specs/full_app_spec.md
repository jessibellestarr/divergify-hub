# Divergify Full App (v1) – High Level
- Accounts + privacy toggles (Tin Foil Hat Mode).
- Divergipedia integrated.
- Sidekick embedded.
- Basic analytics (local-only by default; opt-in to sync).
- Monetization: merch, Ko‑fi donations, premium templates (later).
