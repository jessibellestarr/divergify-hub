# Divergify Full Site — Linux + Netlify Ready
Production URL: https://www.divergify.app
Stripe wired with TEST key (works end-to-end). Swap to live key later.

Dev: npm i && npm run dev
Deploy: netlify deploy --build --prod
