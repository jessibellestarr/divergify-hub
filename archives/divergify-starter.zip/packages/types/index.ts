export type Task = {
  id: string;
  title: string;
  notes?: string;
  done: boolean;
  createdAt: string;
  updatedAt: string;
};
