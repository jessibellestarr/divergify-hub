# Divergify Starter (MVP Scaffold)

This repo gives you a **copy‑paste** starting point for:
- **apps/server** (Fastify + Prisma + Postgres + Redis)
- **apps/mobile** (React Native + Expo + TypeScript)
- **packages/types** (shared interfaces)

It includes:
- Dopamine **quip engine** with a 72‑hour no‑repeat rule
- Tasks API + basic auth placeholder (magic links later)
- Local notifications + "Tin Foil Hat" privacy toggle (client-side)
- Docker Compose for Postgres + Redis
- Prisma schema & seed
- GitHub Actions CI

> Goal: run everything locally fast, then evolve.

---

## Quick Start

### 0) Prereqs
- Node 20+
- Yarn or pnpm (recommend **pnpm**)
- Docker Desktop (for db/redis)
- Expo CLI (`npm i -g expo`) and Expo Go app on phone

### 1) Boot the Infra
```bash
docker compose up -d
```

### 2) Install deps
```bash
pnpm i
```

### 3) Server: migrate + seed + run
```bash
cp apps/server/.env.example apps/server/.env
pnpm -C apps/server prisma:migrate
pnpm -C apps/server prisma:seed
pnpm -C apps/server dev
```
Server runs on `http://localhost:4000`

### 4) Mobile: run Expo
```bash
cp apps/mobile/.env.example apps/mobile/.env
pnpm -C apps/mobile start
```
Scan the QR code with Expo Go.

---

## Packages

- `apps/server`: Fastify API with Prisma and endpoints:
  - `GET /health`
  - `GET /tasks`
  - `POST /tasks`
  - `PATCH /tasks/:id`
  - `DELETE /tasks/:id`
  - `POST /rewards/next-quip` (enforces 72h cooldown)

- `apps/mobile`: React Native (Expo managed, TypeScript), tabs:
  - Tasks (add/complete)
  - Rewards (shows quip and triggers local confetti)
  - Settings (Tin Foil Hat toggle)

- `packages/types`: Shared TypeScript interfaces.

---

## Notes

- **Auth** is stubbed (X-User-Id header). Replace with magic link or OAuth later.
- **Quips** are seeded; add more in `apps/server/prisma/seed.ts`.
- **Tin Foil Hat Mode** blocks analytics (none wired) and disables network calls for rewards; tasks stay local.

---

## Scripts

- `pnpm -C apps/server dev` – run API in watch mode
- `pnpm -C apps/server build && pnpm -C apps/server start` – prod build
- `pnpm -C apps/mobile start` – run Expo dev
- `pnpm -C apps/server prisma:migrate` – run migrations
- `pnpm -C apps/server prisma:seed` – seed quips

---

## License
MIT (change as you need)
