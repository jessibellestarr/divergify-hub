import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

const quips = [
  { text: "First task of the day? That’s a heroic start—cape optional.", tag: "start", weight: 2 },
  { text: "You just slayed a micro‑step. Hydra heads trembling.", tag: "progress", weight: 3 },
  { text: "Focus level: Jedi. Distractions: stormtrooper aim.", tag: "focus", weight: 2 },
  { text: "Another task down. Dopamine fairy left a tip.", tag: "progress", weight: 3 },
  { text: "You didn’t get distracted; you strategically pivoted. Nice.", tag: "reframe", weight: 1 },
  { text: "Momentum unlocked. The shiny things can wait.", tag: "focus", weight: 2 }
];

async function main() {
  for (const q of quips) {
    await prisma.quip.upsert({
      where: { text: q.text },
      update: {},
      create: q
    });
  }
  console.log('Seeded quips:', quips.length);
}

main().finally(() => prisma.$disconnect());
