import Fastify from 'fastify';
import cors from '@fastify/cors';
import swagger from '@fastify/swagger';
import swaggerUi from '@fastify/swagger-ui';
import { PrismaClient } from '@prisma/client';
import { z } from 'zod';
import { addHours, subHours } from 'date-fns';

const prisma = new PrismaClient();
const app = Fastify({ logger: true });

await app.register(cors, { origin: true });
await app.register(swagger, { openapi: { info: { title: 'Divergify API', version: '0.1.0' } } });
await app.register(swaggerUi, { routePrefix: '/docs' });

const PORT = Number(process.env.PORT || 4000);
const COOLDOWN_HOURS = Number(process.env.QUIP_COOLDOWN_HOURS || 72);

// Simple user injection via header (stub auth). Replace later.
app.addHook('preHandler', async (req, _reply) => {
  const userHeader = req.headers['x-user-id'];
  let userId: string;
  if (typeof userHeader === 'string') {
    userId = userHeader;
  } else {
    // demo: ensure a default user exists
    const demo = await prisma.user.upsert({
      where: { email: 'demo@local' },
      update: {},
      create: { email: 'demo@local' }
    });
    userId = demo.id;
  }
  (req as any).userId = userId;
});

app.get('/health', async () => ({ ok: true }));

// Tasks
app.get('/tasks', async (req) => {
  const userId = (req as any).userId as string;
  return prisma.task.findMany({ where: { userId }, orderBy: { createdAt: 'desc' } });
});

app.post('/tasks', async (req, reply) => {
  const userId = (req as any).userId as string;
  const body = z.object({ title: z.string().min(1), notes: z.string().optional() }).parse(req.body);
  const t = await prisma.task.create({ data: { userId, title: body.title, notes: body.notes } });
  return reply.code(201).send(t);
});

app.patch('/tasks/:id', async (req, reply) => {
  const userId = (req as any).userId as string;
  const params = z.object({ id: z.string() }).parse(req.params);
  const body = z.object({ title: z.string().optional(), notes: z.string().optional(), done: z.boolean().optional() }).parse(req.body);
  const t = await prisma.task.update({ where: { id: params.id }, data: { ...body } });
  if (t.userId !== userId) return reply.code(403).send({ error: 'Forbidden' });
  return t;
});

app.delete('/tasks/:id', async (req, reply) => {
  const userId = (req as any).userId as string;
  const params = z.object({ id: z.string() }).parse(req.params);
  const t = await prisma.task.findUnique({ where: { id: params.id } });
  if (!t || t.userId !== userId) return reply.code(404).send({ error: 'Not found' });
  await prisma.task.delete({ where: { id: params.id } });
  return { ok: true };
});

// Rewards: 72h no-repeat quip
app.post('/rewards/next-quip', async (req, reply) => {
  const userId = (req as any).userId as string;
  const since = subHours(new Date(), COOLDOWN_HOURS);

  // get quips not shown in last COOLDOWN_HOURS
  const recent = await prisma.quipHistory.findMany({
    where: { userId, shownAt: { gt: since } },
    select: { quipId: true }
  });
  const blocked = new Set(recent.map(r => r.quipId));

  const pool = await prisma.quip.findMany();
  const candidates = pool.filter(q => !blocked.has(q.id));

  const pick = (arr: typeof pool) => {
    if (!arr.length) return null;
    const total = arr.reduce((acc, q) => acc + (q.weight || 1), 0);
    let r = Math.random() * total;
    for (const q of arr) {
      r -= (q.weight || 1);
      if (r <= 0) return q;
    }
    return arr[0];
  };

  let chosen = pick(candidates);
  if (!chosen) {
    // fallback: choose the least recent shown
    const last = await prisma.quipHistory.groupBy({
      by: ['quipId'],
      where: { userId },
      _max: { shownAt: true }
    });
    const byId = Object.fromEntries(last.map(x => [x.quipId, x._max.shownAt || new Date(0)]));
    pool.sort((a, b) => (byId[a.id]?.getTime() || 0) - (byId[b.id]?.getTime() || 0));
    chosen = pool[0];
  }

  if (!chosen) return reply.code(404).send({ error: 'No quips available' });

  await prisma.quipHistory.create({ data: { userId, quipId: chosen.id } });
  return { quip: chosen.text, tag: chosen.tag };
});

app.listen({ port: PORT, host: '0.0.0.0' }).then(() => {
  app.log.info(`API on http://localhost:${PORT}`);
});
