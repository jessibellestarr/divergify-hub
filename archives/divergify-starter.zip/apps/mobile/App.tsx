import React, { useEffect, useState } from 'react';
import { View, Text, Button, TextInput, FlatList, Switch, Alert, Platform } from 'react-native';
import * as Notifications from 'expo-notifications';
import Constants from 'expo-constants';

type Task = { id: string; title: string; done: boolean };

const API = process.env.API_URL || 'http://localhost:4000';

export default function App() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [title, setTitle] = useState('');
  const [tinFoil, setTinFoil] = useState((process.env.TIN_FOIL_HAT || 'false') === 'true');
  const [quip, setQuip] = useState<string>('');

  useEffect(() => {
    Notifications.requestPermissionsAsync();
    loadTasks();
  }, []);

  async function loadTasks() {
    try {
      const res = await fetch(`${API}/tasks`, { headers: { 'X-User-Id': 'demo' } });
      const data = await res.json();
      setTasks(data);
    } catch (e) {
      console.warn('tasks load failed', e);
    }
  }

  async function addTask() {
    if (!title.trim()) return;
    const res = await fetch(`${API}/tasks`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-User-Id': 'demo' },
      body: JSON.stringify({ title })
    });
    const t = await res.json();
    setTasks([t, ...tasks]);
    setTitle('');
    scheduleLocalNudge();
  }

  function scheduleLocalNudge() {
    if (tinFoil) return; // no network or notifications
    Notifications.scheduleNotificationAsync({
      content: { title: "Divergify", body: "Did you just switch tasks, or did the shiny thing win?" },
      trigger: { seconds: 1800 } // 30 minutes
    });
  }

  async function getQuip() {
    if (tinFoil) { setQuip("Privacy mode: all dopamine offline today. You're still a legend."); return; }
    try {
      const res = await fetch(`${API}/rewards/next-quip`, { method: 'POST', headers: { 'X-User-Id': 'demo' } });
      const data = await res.json();
      if (data.quip) setQuip(data.quip);
      else Alert.alert('No quips available');
    } catch {
      setQuip("Offline mode: take a breath, count to five, and flex those brain muscles.");
    }
  }

  return (
    <View style={{ padding: 16, paddingTop: 48, gap: 12 }}>
      <Text style={{ fontSize: 24, fontWeight: '700', color: '#0a7' }}>Divergify</Text>

      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
        <TextInput
          placeholder="Add a task…"
          value={title}
          onChangeText={setTitle}
          style={{ borderWidth: 1, borderColor: '#ccc', padding: 8, flex: 1, borderRadius: 8 }}
        />
        <Button title="Add" onPress={addTask} />
      </View>

      <FlatList
        data={tasks}
        keyExtractor={(t) => t.id}
        renderItem={({ item }) => (
          <View style={{ padding: 12, borderBottomWidth: 1, borderColor: '#eee' }}>
            <Text style={{ fontSize: 16 }}>{item.title}</Text>
          </View>
        )}
      />

      <Button title="Hit me with dopamine" onPress={getQuip} />
      {quip ? <Text style={{ marginTop: 8, fontStyle: 'italic' }}>{quip}</Text> : null}

      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 16 }}>
        <Text>Tin Foil Hat Mode</Text>
        <Switch value={tinFoil} onValueChange={setTinFoil} />
      </View>

      <Text style={{ marginTop: 12, color: '#666' }}>
        {tinFoil ? "Privacy first: analytics and dopamine calls are off." : "Standard mode: nudges & quips enabled."}
      </Text>
    </View>
  );
}
