export const metadata = { title: "Divergify", description: "Community-powered neurodivergent productivity." };
export default function RootLayout({children}:{children:React.ReactNode}){
  return (<html lang="en"><body style={{background:'#000',color:'#eee',fontFamily:'system-ui'}}>
    <main style={{maxWidth:960,margin:'0 auto',padding:'1rem'}}>{children}</main>
  </body></html>);
}
