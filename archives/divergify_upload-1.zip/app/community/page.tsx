export default function Community() {
  return (
    <div>
      <h1>Community</h1>
      <p style={{ color: '#9ca3af' }}>
        Profiles, posts, comments coming after auth.
      </p>
    </div>
  );
}
