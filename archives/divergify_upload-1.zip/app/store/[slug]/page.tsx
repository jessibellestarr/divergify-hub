import products from '../../../lib/products.json';
import { notFound } from 'next/navigation';

export default function Product({ params }: { params: { slug: string } }) {
  const p: any = products.find((x: any) => x.slug === params.slug);
  if (!p) return notFound();
  return (
    <div>
      <h1>{p.title}</h1>
      <p>{p.description}</p>
      <p>${(p.priceCents / 100).toFixed(2)}</p>
      <form action="/api/checkout" method="POST">
        <input type="hidden" name="slug" value={p.slug} />
        <button type="submit">Buy</button>
      </form>
    </div>
  );
}
